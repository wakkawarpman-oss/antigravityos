HANNA pre-launch bundle

Generated: 20260410T200817
Root: /Users/admin/Downloads/hanna-v3-2-clean-master

Artifacts:
- run_discovery.list.txt / .err
- hanna_ui.help.txt / .err
- inventory.json
- preflight.json
- status.txt
- smart-summary.json
- final-summary.json
- gate-result.json
- pytest.txt
- tor-policy.json / .err
- live-smoke.json / .err
- full-rehearsal.runtime.json / .err
- full-rehearsal.metadata.json
- full-rehearsal.verification.json / .err

Interpretation:
- Any non-empty *.err should be reviewed.
- preflight.json must not show blocking dependency failures for the intended rollout preset.
- gate-result.json must report no required_check_failures for release-green verdict.
- pytest.txt must end with all selected tests passing.
- final-summary.json is the machine-readable verdict for automation and release gates.
